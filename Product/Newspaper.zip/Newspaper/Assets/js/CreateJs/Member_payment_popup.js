a=false;
$(document).ready(function(){
  // stocks();
$("#infosave").click(function(){
if(a==false){
  stocksave();
  
 }
  });
});

function stocksave()
{


    // var StockID =$('#StockID').val();
    // var StockNm=$('#StockNm').val(); 
    var fullname = $('#fullname').val();
     var mobile = $("#mobile").val();
     var dob = $("#dob").val();
     var todaydate = $('#todaydate').val();
    
  


     if(fullname=="" || mobile=="" || dob=="" || todaydate=="" )
{
    
    Swal.fire({
          title: 'Oops!',
          text: 'Please Enter Required Fields!',
          icon: 'error',
          showConfirmButton : false,
          timer: 5000,
          timerProgressBar: true
        })
        
}
    
    else
    {      
      
        $.ajax({
              url:base_path+"Member_payment/insertMember",
              type: "POST",
           
              data: $('#Regform').serialize(),
              beforeSend: function(){
              $('#infosave').prop('disabled', true);
              $('#infosave').html('<i class="fa fa-spinner " style="padding-right:2%;"></i> Loading');
              }, 
               success: function(data) { 
                console.log(data);
              // $("#patientForm").trigger("reset");
              
              $('#infosave').html('<i class="fa fa-check-circle" style="font-size: 20px;color: #FFF;"></i>Save');
              $('#infosave').prop('disabled', false);
           
             Swal.fire({
                title: 'Good job!',
              text: 'Data Submitted Successfully!',
              icon: 'success',
              showConfirmButton : false,
              timer: 900,
              timerProgressBar: true
            })

            setTimeout(function () {
              window.location.reload();
              $("#newmodal").modal("hide");
            }, 1000);
            
            stocks();
           
           a=false;
          
            
            
               }
          });    
            
    }
    
    


  }