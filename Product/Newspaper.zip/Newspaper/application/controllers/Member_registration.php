<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Member_registration extends CI_Controller{

	public function __construct()
    {
        parent::__construct();
        $this->load->model('Member_registration_model');
        
    }



    public function index()
	{
        $data['alldata']=$this->Member_registration_model->getdetailMemberRegistration();
        $current_date = date('Y-m-d', strtotime('now'));
    $data['formatted_date'] = date('d-M-Y', strtotime($current_date));
    
        // echo "<pre>";
        // print_r($data);

		$this->load->view('common/header_view');
        $this->load->view('Member_registration/Member_registration_detailview',$data);
		$this->load->view('common/footer_view');
	

	}

    public function create(){

        
        // $data['Structuredata']=$this->Business_model->getstructure();
        // $data['Statedata']=$this->bank_model->getState();


		$this->load->view('common/header_view');
		$this->load->view('Member_registration/Member_registration_view',);
		$this->load->view('common/footer_view');
    }
   

	function insertMember(){
        $fullname= $this->input->post('fullname'); 
        $mobile= $this->input->post('mobile');
        $dob=$this->input->post('dob');
        $date=$this->input->post('date');
       

       $fields=array('Member_fullname'=>$fullname,
                      'Mobile'=>$mobile,
                      'DOB'=> date('Y-m-d', strtotime($this->input->post('dob'))),                    
                      'Registration_date'=> date('Y-m-d', strtotime($this->input->post('date')))                    
                     


                    );

                    // echo "<pre>";
                    // print_r($fields);
            $this->Member_registration_model->insertdata($fields);
			echo json_encode($fields);

            // echo json_encode($fields);
        
    
   } 


   public function update()
   {
       $id=$this->uri->segment(3);
          $data['data']=$this->Member_registration_model->getbyid($id);

        
       //  echo "<pre>";
       // print_r($data);
        
		$this->load->view('common/header_view');
		$this->load->view('Member_registration/Member_registration_view',$data);
		$this->load->view('common/footer_view');
   }


   public function updateregistration()
   {
       $Mr_Id= $this->input->post('Mr_Id'); 
       $fullname= $this->input->post('fullname'); 
        $mobile= $this->input->post('mobile');
        $dob=$this->input->post('dob');
        $date=$this->input->post('date');



        $fields=array( 'Mr_Id'=>$Mr_Id,
            'Member_fullname'=>$fullname,
        'Mobile'=>$mobile,
        'DOB'=>$dob,
        'Registration_date'=>$date
    
    );
       $this->Member_registration_model->update($fields);
   }

}
?>