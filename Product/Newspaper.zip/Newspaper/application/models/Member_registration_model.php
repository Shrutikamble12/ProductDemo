<?php
  class Member_registration_model extends CI_Model {
    public function __construct()
      {
          $this->load->database();
      }
  
      public function insertdata($model)
	{
		return $this->db->insert('memberinfo',$model);
			//return $sql->result();
	} 

  public function getdetailMemberRegistration()
  {      
   
     $this->db->select('memberinfo.Mr_Id,memberinfo.Member_fullname,memberinfo.Mobile,memberinfo.DOB,memberinfo.Registration_date,');
     $this->db->from('memberinfo');
    //  $this->db->join('business_structure','business.Business_Structure = business_structure.Structure_ID','left');
    //  $this->db->join('student_sub','studentdetails.Subject = student_sub.sub_id','left');
     $this->db->order_by('memberinfo.Mr_Id','DESC');
     $query = $this->db->get();
     return $query->result();
          
  }


  public function getbyid($id)
		{
      $this->db->select('memberinfo.Mr_Id,memberinfo.Member_fullname,memberinfo.Mobile,memberinfo.DOB,memberinfo.Registration_date,');
	    $this->db->where('Mr_Id',$id);
      $query = $this->db->get('memberinfo');
			return $query->result();
		}
		
    public function update($model)
    {
       return $sql = $this->db->where('Mr_Id',$model['Mr_Id'])->update('memberinfo',$model); 
    } 
}
