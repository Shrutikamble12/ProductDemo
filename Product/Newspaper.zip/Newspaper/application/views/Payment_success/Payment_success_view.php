<style>

.select2{
    width:100% !important;
}
</style>


<link rel="stylesheet" href="<?=base_url();?>Assets/select2/select2.min.css" />
<link rel="stylesheet" href="<?=base_url();?>Assets/select2/multiselect.css" />

        <!-- =============== Left side End ================-->
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
                
                <div class="separator-breadcrumb border-top"></div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                        <div class="breadcrumb mb-0" style="border-bottom: 1px solid #aaaaaa;">
                                 <h1 style="font-family: 'Work Sans', sans-serif;">Payment Report</h1>
                        </div>
                            <div class="card-body">
                            <form role="form" id="Form" method="post">
                            <input class="form-control" id="Mr_Id" name="Mr_Id" type="hidden" value="<?= !empty($data) ? $data[0]->Mr_Id : '' ?>" />

                            <div class="row">
                                <div class="col-md-3 form-group mb-3">
                                    <label for="month">Select Month</label>
                                    <input type="month" name="month" id="month" class="form-control" required>
                                </div>

                                <div class="col-md-3 form-group mb-3">
                                    <label for="name">Select Member Name</label>
                                    <select name="name" id="name" class="form-control select2" required>
                                        <option value="0">--Select--</option>
                                        <?php 
                                                foreach($Mnamedata as $rw=>$value){
                                                    $selected="";
                      
                                                    if(!empty($data[0]->Mname)){
                                                                    
                                                    if ($value->Mr_Id == $data[0]->Mname) {
                                                      $selected="selected='selected'";
                                                    } 
                                                  } 
                                                  echo '<option value="'.$value->Mr_Id.'"'.$selected.' >'.$value->Member_fullname.''.$selected.' '.$value->Mobile. '</option>';
                                            
                                            
                                            
                                                 }
                                                   ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row mt-3">
                                <div class="col-md-12 text-right">
                                    <button class="btn btn-three btn-rounded btn-lg" type="button" name="search" id="search">
                                    <img src="<?=base_url();?>Assets/images/suc.png" width="21">&nbsp;Success</button>
                                </div>
                            </div>

                            <div class="row mt-3">
                                <div class="col-md-12 text-right">
                                    <button class="btn btn-four btn-rounded btn-lg" type="button" name="search1" id="search1">
                                    <img src="<?=base_url();?>Assets/images/unsuc.png" width="21">&nbsp;Unsuccess</button>
                                </div>
                            </div>

                            <div class="row mt-3">
                                <div class="col-md-12 text-right">
                                <a class="btn btn-six text-white btn-rounded" href="<?=base_url()?>Member_payment/create">
                                <i class="fa-solid fa-money-check-dollar"></i>&nbsp;Payment</a>
                                </div>
                            </div>

                        </form>
                        <div class="table-responsive mt-5" id="tdatas">
                            <table class="display table table-striped table-bordered" id="example" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Sr.No</th>
                                        <th>Name</th>
                                        <th>Amount</th>
                                        <th>P_Date</th>
                                    </tr>
                                </thead>
                                <tbody id="tabledata">
                                    <!-- Data will be loaded here by AJAX -->
                                </tbody>
                            </table>
                        </div>

                            </div>
                        </div>
                        
                    </div>
</div>
                  

<!-- <script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/StudentCreate.js"></script> -->

<script  src="<?php echo base_url();?>Assets/js/jquery.min.js"></script>           

<script src="<?= base_url(); ?>Assets/js/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script src="<?= base_url(); ?>Assets/js/CreateJs/Member_registration.js"></script>
    <script src="<?= base_url(); ?>Assets/select2/select2.min.js"></script>
    <script src="<?= base_url(); ?>Assets/select2/select2.init.js"></script>

    <script>
        const monthControl = document.querySelector('input[type="month"]');
const date= new Date()
const month=("0" + (date.getMonth() + 1)).slice(-2)
const year=date.getFullYear()
monthControl.value = `${year}-${month}`;
    </script>
    
    <script>
        $(document).ready(function () {
            $('.select2').select2();

            $('#search').click(function () {
                getMonthData();
            });
        });

        function getMonthData() {
            var selectedMonth = $("#month").val();
            var selectedName = $("#name").val();

            $.ajax({
                url: "<?= base_url() ?>Payment_success/getMonthData",
                method: 'post',
                data: {
                    'month': selectedMonth,
                    'name': selectedName
                },
                success: function (data) {
                    $("#tabledata").empty().html(data);
                    amountcalculation();
                    formatPaymentDate();
                    countIDs();
                }
            });
            $('#month').val('').trigger('change');
           $('#name').val('0').trigger('change');
        }
      
        
        function formatPaymentDate() {
            $('#tabledata tr').each(function (index) {
                if (index > 0) {
                    var paymentDate = $(this).find('td:eq(3)').text().trim();
                    if (isValidDate(paymentDate)) {
                        var formattedDate = new Date(paymentDate).toLocaleDateString('en-GB', {
                            day: '2-digit',
                            month: 'short',
                            year: 'numeric'
                        });
                        $(this).find('td:eq(3)').text(formattedDate);
                    }
                }
            });
        }

        function isValidDate(dateString) {
            var regexDate = /^\d{4}-\d{2}-\d{2}$/;
            return regexDate.test(dateString);
        }

        function amountcalculation() {
            var charges = document.getElementsByClassName("Mamount");
            var Totalcharges = 0;
            for (var p = 0; p < charges.length; p++) {
                Totalcharges += parseFloat(charges[p].value);
            }
            document.getElementById("BillTot").value = Totalcharges.toFixed(2);
            $('#textt').text(Totalcharges.toFixed(2));
        }
    </script>

    <script>
        $(document).ready(function () {
            $('.select2').select2();

            $('#search1').click(function () {
                getUnsuccess();
            });
        });

        function getUnsuccess() {
            var selectedMonth = $("#month").val();
            var selectedName = $("#name").val();
            

            $.ajax({
                url: "<?= base_url() ?>Payment_success/getUnsuccessData",
                method: 'post',
                data: {
                    'month': selectedMonth,
                    'name': selectedName
                },
                success: function (data) {
                    $("#tabledata").empty().html(data);
                    amountcalculation();
                    formatPaymentDate();
                    countIDnew();
                }
            });
        }
      
    </script>

<script>

        
document.addEventListener("DOMContentLoaded", function() {
    countIDs();
});

function countIDs() {    
    var idCells = document.getElementsByClassName("id-cell");
    var totalIDs = idCells.length;
    console.log("Total IDs count:", totalIDs);
    var textElement = document.getElementById("text");
    if (textElement) {
        textElement.textContent = totalIDs;
    }
    //  else {
    //     console.error("Element with id 'text' not found.");
    // }
}



</script>

<script>

        
document.addEventListener("DOMContentLoaded", function() {
    countIDnew();
});

function countIDnew() {    
    var idCel = document.getElementsByClassName("id-cel");
    var totalIDs = idCel.length;
    console.log("Total IDs count:", totalIDs);
    var textElement = document.getElementById("untext");
    if (textElement) {
        textElement.textContent = totalIDs;
    }
    //  else {
    //     console.error("Element with id 'text' not found.");
    // }
}



</script>
