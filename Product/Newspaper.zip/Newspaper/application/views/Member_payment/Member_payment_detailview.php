 <!-- =============== Left side End ================-->
 <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
               
                
                <div class="separator-breadcrumb border-top"></div>
                <div class="row">
                
                    <div class="col-md-12">
                        <div class="card">
                        <div class="breadcrumb mb-0 " style="border-bottom: 1px solid #aaaaaa;">
                    <h1 style="font-family: 'Work Sans', sans-serif;">PAYMENT LIST</h1>
                   
                </div>
                        <div class="card-body">
                        <a class="btn btn-five text-white btn-rounded" href="<?=base_url()?>Payment_success/create">Report </a>
                        <a class="btn btn-seven text-white btn-rounded" href="<?=base_url()?>Member_payment/create">Payment</a>
                            <button class="btn btn-new mb-3" ><a href="<?=base_url() ?>Member_payment/create" class="text-decoration-none text-white "><i class="fa-solid fa-plus"></i>&nbsp;Add New</a></button><br>
                                <div class="table-responsive">
                                    <table class="display table" id="example" style="width:100%">
                                        <thead class="Heading-table">
                                            <tr>
                                                <th>Action</th>
                                                <th>Id</th>
                                                <th>Name</th>
                                                <th>Amount</th>
                                                <th>P_Date</th>
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                        
                                          
                                         <?php 
                                             $i=0;
                                             foreach($alldata as $rw=>$value){
                                             $formatted_date = date('d-M-Y', strtotime($value->Pdate));
                                             

                                                
                                                //  $gender=$value->Gender;
                                                //  if ($gender== 1){
                                                //      $g='Male';
                                                //  }else{
                                                //      $g='Female';
                                                //  }

                                         echo "<tr>";

                                            
                                            echo  '<td><a   href="'.base_url().'Member_payment/update/'.$value->Id.'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa-regular fa-pen-to-square" ></i></a> 
                                                 </td>';
                                            
                                            echo "<td>".$value->Id."</td>";
                                            echo "<td>".$value->Member_fullname."</td>";
                                            echo "<td>".$value->Mamount."</td>";
                                            echo "<td>".$formatted_date."</td>";
                                
                                        

                                           
                                            $i++;
                                        
                                            echo "</tr>";                        
                                        }
                                        ?> 
                             
                                
                                          
                                        </tbody>
                                        
                                    </table>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
</div>
                  

<script  src="<?php echo base_url(); ?>web_resources/dist/js/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>

<script>
	$(document).ready(function() {
   

    $('#example').dataTable( {} );
 
    
} );
</script>
                   