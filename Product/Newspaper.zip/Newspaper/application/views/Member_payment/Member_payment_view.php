<link rel="stylesheet" href="<?=base_url();?>Assets/select2/select2.min.css" />
<link rel="stylesheet" href="<?=base_url();?>Assets/select2/multiselect.css" />

        <!-- =============== Left side End ================-->
        
          
        
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
                
                <div class="separator-breadcrumb border-top"></div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                        <div class="breadcrumb mb-0" style="border-bottom: 1px solid #aaaaaa;">
                                 <h1 style="font-family: 'Work Sans', sans-serif;">Member Payment</h1>
                        </div>
                            <div class="card-body">
                                <form role="form" id="Form" action="" method="post">

                                <?php if (!empty($data)) : ?>
        <script>
            document.addEventListener('DOMContentLoaded', () => {
                document.getElementById('formMode').value = 'update';
                document.getElementById('btnhide').disabled = true; // Disable button when in update mode
            });
        </script>
    <?php endif; ?>

    <input type="hidden" id="formMode" value="add" />
    
                                    <div class="row">
                                    <input class="form-control" Id="Id"  placeholder="Enter your ID" name="Id"
                                     value="<?php if(!empty($data)) echo $data[0]->Id ; ?>" type="hidden"/>

                                     <div class="">
                                          <button type="button" class="btnn text-white" id="btnhide" data-toggle="modal" data-target="#newmodal">
                                          <i class="fa-solid fa-plus" style="color: #ffffff;"
                                          ></i>&nbsp;Add New
                                        </button>
                                        </div>
                                
                                     <div class=" col-md-3 form-group Mname">
                                        <label for="name">Member Name</label>
                                        
                                            <select class="select2 form-control " name="name" id="name" onchange="ShareMarkets()" value="<?php if(!empty($data)) echo $data[0]->Mname ; ?>">
                                                <option value="0">--Select--</option>
                                  
                        <?php 
                                                foreach($Mnamedata as $rw=>$value){
                                                    $selected="";
                      
                                                    if(!empty($data[0]->Mname)){
                                                                    
                                                    if ($value->Mr_Id == $data[0]->Mname) {
                                                      $selected="selected='selected'";
                                                    } 
                                                  } 
                                                  echo '<option value="'.$value->Mr_Id.'"'.$selected.' >'.$value->Member_fullname.''.$selected.' '.$value->Mobile. '</option>';
                                            
                                            
                                                 }
                                                   ?>
                                              
                                            </select>
                                       
                                        </div>
                                    
                                    
                                       
                                      

                                            <div class="col-md-2 form-group">
                                            <label for="amount">Amount (Rs.)</label>
                                            <input type="number" name="amount" id="amount" class="form-control"value="<?php if(!empty($data)) echo $data[0]->Mamount ; ?>"  style=" width: 220px;">
                                            </div>
                                        

                                        
                                            <div class="col-md-2 form-group">
                                            <label for="date">Payment Date</label>
                                           
                                            <input type="date" name="date" id="date" class="form-control" value="<?php if(!empty($data)) echo $data[0]->Pdate ; ?>" style=" width: 220px;" >
                                            </div>

                                            <!-- <div class="col-md-2 form-group">
                                            <input class="form-control" Id="month" name="month"
                                     value="<?php if(!empty($data)) echo $data[0]->Month ; ?>" type="hidden"/>

                                            </div> -->

                                            </div>

                                   
                                            <div class="row mt-3">
                                    <div class="col-md-12 text-right">
                                            <button class="btn btn-one btn-rounded" type="button" name="btn_save" id="btn_save">
                                        <!-- <img src="<?=base_url();?>Assets/images/save1.png" width="21"> -->
                                         Save</button>

                                        <a class="btn btn-two text-white btn-rounded" href="<?=base_url()?>Member_payment/index">
                                        <!-- <img src="<?=base_url();?>Assets/images/editt.png" width="21">&nbsp; -->
                                        Edit</a>

                                        <a class="btn btn-five text-white btn-rounded" href="<?=base_url()?>Payment_success/create">Report </a>
                                        <!-- <img src="<?=base_url();?>Assets/images/editt.png" width="21">&nbsp;Report</a> -->


                                            <!-- <button class="btn btn-warning text-white" type="button" name="cancel" id="cancel">Cancel</button> -->

                                        </div> 
                                        </div>
                                   
                                </form>

                                
                               

                                <div class="table-responsive mt-5" id="tdatas">
                                   <table class="display table table-striped table-bordered" id="example" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>Sr.No</th>
                                                <!-- <th>Name</th> -->
                                                <th>Amount</th>
                                                <th>P_Date</th>
                                    

                                            </tr>
                                        </thead>
                                        <tbody id="tabledata"> 
                                        </tbody>
                                        
                                    </table>
                                   
                                </div>

                            </div>
                        </div>
                         <div class="modal" id="newmodal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header" style="display: flex; justify-content: space-between;border-bottom: 2px solid #47484b!important;">
          <h4 class="modal-title" style="font-family: 'Work Sans', sans-serif;">Member registration</h4>
          <button type="button" class="close Modal_close-icon" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
            <form class="needs-validation" id="Regform"  >

                 
                 
 
                      <div class="row">
                                    <input class="form-control" Id="Mr_Id"  placeholder="Enter your ID" name="Mr_Id"
                                     value="<?php if(!empty($data)) echo $data[0]->Mr_Id ; ?>" type="hidden"/>
                                        <div class="col-md-12 form-group mb-3">
                                            <label for="name">Member Full Name</label>
                                           <input type="text" name="fullname" id="fullname" class="form-control">
                                           
                                        </div>
                                        
                                        
                                            <div class="col-md-12 form-group">
                                            <label for="mobile">Mobile No</label>
                                            <input type="number" name="mobile" id="mobile" class="form-control"  onKeyPress="if(this.value.length==10) return false;">
                                
                                            </div>
                                        

                                        
                                            <div class="col-md-12 form-group">
                                            <label for="date">Birth Date</label>
                                            <input type="date" name="dob" id="dob" class="form-control">
                                
                                            </div>

                                            <div class="col-md-12 form-group">
                                            <label for="date">Registration Date</label>
                                            <input type="date" name="date" id="todaydate" class="form-control" >
                            
                                            </div>

                                            </div>

                                            <div class="row mt-3">
                                        <div class="col-md-12 text-right modal-footer">

                                            <button class="btn btn-one btn-rounded " type="button" name="infosave"
                                                id="infosave">Save</button>
                                                <!-- <img src="<?=base_url();?>Assets/images/save1.png" width="21">&nbsp; -->
                                               
                                            
                                            <a class="btn btn-two text-white btn-rounded"
                                                href="<?= base_url() ?>Member_registration/index">
                                                <!-- <img src="<?=base_url();?>Assets/images/editt.png" width="21">&nbsp; -->
                                                Edit</a>
                                        

                                        </div>

                                    </div>
                                       
                                   


                                   

                                   
                                   


                                   

                                    
                                   
                    </div>
               
            </form>
        </div>
        
       
        
      </div>
    </div>
  </div>
                    </div>
</div>

   

<!-- <script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/StudentCreate.js"></script> -->

<script  src="<?php echo base_url();?>Assets/js/jquery.min.js"></script>           

<script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>

<script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script> 

<script src="<?php echo base_url();?>Assets/js/CreateJs/Member_payment.js"></script>  
<script src="<?php echo base_url();?>Assets/js/CreateJs/Member_payment_popup.js"></script>    
<script src="<?php echo base_url();?>Assets/select2/select2.min.js"></script>
    <script src="<?php echo base_url();?>Assets/select2/select2.init.js"></script>

    <script>
    document.addEventListener('DOMContentLoaded', () => {
        const setDateIfEmpty = 1f194_squaredid => {
            const input = document.getElementById1f194_squaredid;
            if (!input.value) input.valueAsDate = new Date();
        };
        setDateIfEmpty("dob");
        setDateIfEmpty("todaydate");
        setDateIfEmpty("date");

        // Disable the button if the form is in update mode
        const formMode = document.getElementById('formMode').value;
            const btnHide = document.getElementById('btnhide');
            btnHide.disabled = (formMode === 'update');

            // Initialize Select2
            $('.select2').select2();
        });

    function ShareMarkets() {
        var Mr_Id = $("#name").val();
        $.ajax({
            url: "<?php echo base_url()?>Member_payment/getpaymentdata",
            method: 'post',
            data: {'Mr_Id': Mr_Id},
            success: function(data) {
                $("#tabledata").empty();
                $("#tabledata").html(data);
                amountcalculation();
                formatPaymentDate();
                countIDs();
            }
        });
    }

    function formatPaymentDate() {
        $('#tabledata tr').each(function(index) {
            if (index > 0) {
                var paymentDate = $(this).find('td:eq(2)').text().trim();
                if (isValidDate(paymentDate)) {
                    var formattedDate = new Date(paymentDate).toLocaleDateString('en-GB', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric'
                    });
                    $(this).find('td:eq(2)').text(formattedDate);
                }
            }
        });
    }

    function isValidDate(dateString) {
        var regexDate = /^\d{4}-\d{2}-\d{2}$/;
        return regexDate.test(dateString);
    }

    function amountcalculation() {
        var charges = document.getElementsByClassName("Mamount");
        var Totalcharges = 0;
        for (var p = 0; p < charges.length; p++) {
            Totalcharges = parseInt(charges[p].value) + parseInt(Totalcharges);
        }
        console.log("total charges", Totalcharges);
        document.getElementById("BillTot").value = Totalcharges.toFixed(2);
        $('#textt').text(Totalcharges.toFixed(2));
    }
</script>
<script>

        
        document.addEventListener("DOMContentLoaded", function() {
            countIDs();
        });

        function countIDs() {    
            var idCells = document.getElementsByClassName("id-cell");
            var totalIDs = idCells.length;
            console.log("Total IDs count:", totalIDs);
            var textElement = document.getElementById("text");
            if (textElement) {
                textElement.textContent = totalIDs;
            }
            //  else {
            //     console.error("Element with id 'text' not found.");
            // }
        }

        

</script>
